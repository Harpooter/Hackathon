import { Navbar } from "./navbar";
import { Sidebar } from "./sidebar";

export function DashboardShell({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="flex min-h-screen bg-slate-50">
      <Sidebar />

      <div className="flex flex-1 flex-col">
        <Navbar />

        <main className="dashboard-padding flex-1">
          {children}
        </main>
      </div>
    </div>
  );
}