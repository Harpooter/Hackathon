"use client";

import {
  User,
  onAuthStateChanged,
} from "firebase/auth";
import {
  createContext,
  useEffect,
  useState,
} from "react";

import { auth } from "@/config/firebase";

interface AuthContextType {
  user: User | null;
  loading: boolean;
}

export const AuthContext =
  createContext<AuthContextType>({
    user: null,
    loading: true,
  });

export function AuthProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  const [user, setUser] = useState<User | null>(
    null
  );
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(
      auth,
      (user) => {
        setUser(user);
        setLoading(false);
      }
    );

    return () => unsubscribe();
  }, []);

  return (
    <AuthContext.Provider value={{ user, loading }}>
      {children}
    </AuthContext.Provider>
  );
}